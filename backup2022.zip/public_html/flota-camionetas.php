<?php
header('Location: flota.php');
?>