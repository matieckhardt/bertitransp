<?php phpinfo (); ?>
