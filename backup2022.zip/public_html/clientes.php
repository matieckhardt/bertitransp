<?php include_once 'scripts.php'; ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Berti-Transp &ndash; Clientes</title>

<?php include_once 'head.php'; ?>

</head>
<body id="container">

	<?php include_once 'header.php'; ?>

	<div id="center">
	<div class="section">
		
		<h2 class="title">Clientes</h2>
		
		<div class="col-3of3 col-misc-1">
			<p>Confían en nosotros:</p>
			<p class="col-misc-1">&nbsp;</p>
			<p><img src="src/img/clientes.jpg" clientes></p>
		</div><!-- /col -->
	
	</div><!-- /section -->
	</div><!-- /center -->

	<?php include_once 'footer.php'; ?>

</body>
</html>