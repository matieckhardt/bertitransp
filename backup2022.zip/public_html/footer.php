<div id="footer">
	<p class="copy">Amoroso 702, Esq. Luzuriaga, Hurlingham (1686), Buenos Aires, Argentina <span class="spacer">|</span> (011) 5435-0445 <span class="spacer">|</span> <a href="mailto:info@bertitransp.com.ar">info@bertitransp.com.ar</a></p>
	<p class="design">Diseño por <a href="http://www.diecisietedoce.com/" target="_blank">Diecisietedoce</a></p>
</div><!-- /footer -->
