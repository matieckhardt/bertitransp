<link rel="shortcut icon" href="favicon.ico">

<link rel="stylesheet" href="src/css/fonts.css" type="text/css">
<link rel="stylesheet" href="src/css/styles.css" type="text/css">

<script type="text/javascript" src="src/js/jquery.js" charset="utf-8"></script>
<script type="text/javascript" src="src/js/jquery-easing.js" charset="utf-8"></script>
<script type="text/javascript" src="src/js/main.js" charset="utf-8"></script>

<?php if ( $seccion == "contacto" ) { ?>
<link rel="stylesheet" href="src/css/forms.css" type="text/css">
<script type="text/javascript" src="src/js/validate.js" charset="utf-8"></script>
<?php } ?>
